Installation:

1. Move covid19.widget to your Ubersicht widgets folder.
2. Check index.jsx for configuration
2. Enjoy!